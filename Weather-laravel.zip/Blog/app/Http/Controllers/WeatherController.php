<?php
namespace App\Http\Controllers;
use App\Models\Weather;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Stevebauman\Location\Facades\Location;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Mail;
class WeatherController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
    //$email="zahin.alwa@adsparc.com";
    $email="ajay32852@gmail.com";
    //$response =(object) Http::get("http://dataservice.accuweather.com/locations/v1/topcities/50?apikey=AkyEai7CnurP1G1tgZZ4QHjeR3CnkNKA")->json();
    //$currentconditions = Http::get("http://dataservice.accuweather.com/currentconditions/v1/topcities/50?apikey=AkyEai7CnurP1G1tgZZ4QHjeR3CnkNKA")->json();
    //  Write Excel file Code
   // echo "<pre>";
   // print_r($currentconditions);
    $arr = [
            'name' => 'ajay', 'Country' =>'India',
            'Region' => 'India', 'Timezone' =>'Asia/Kolkata',
            'Rank' => 10, 'Latitude' =>12.90,
            'Longitude' => 12.88, 'Weather' =>'partly cloud',
            'Text' => true, 'Temperature' =>12.90,
            'Celsius((C))' => 91, 'Last Updated At' =>'20/05/2022 at 2:30 pm IST',
    ];
    $path= public_path('files/Weather_reporting.csv');
    $data1 = Excel::import($arr,$path);
    if ($data1) {
        $data["email"] = $email;
        $data["title"] = "Weather Report";
        $data["body"] = "This is weekely Weather Report Auto genrated";
        $files = [
            public_path('files/Weather_reporting.csv'),
        ];
        Mail::send('email.myTestMail', $data, function($message)use($data, $files) {
            $message->to($data["email"], $data["email"])
                    ->subject($data["title"]);
            foreach ($files as $file){
                $message->attach($file);
            }
        });
        echo "Weather Report Send Sucssfully";
    }else{
        echo "Faild";
    }
}
public function truckstopPost()
{   
        $data["email"] = "ajay32852@gmail.com";
        $data["title"] = "Weather Report";
        $data["body"] = "This is weekely Weather Report Auto genrated";
        $files = [
            public_path('files/Weather_reporting.csv'),
        ];
        Mail::send('email.myTestMail', $data, function($message)use($data, $files) {
            $message->to($data["email"], $data["email"])
                    ->subject($data["title"]);
            foreach ($files as $file){
                $message->attach($file);
            }
        });
}
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Weather  $weather
     * @return \Illuminate\Http\Response
     */
    public function show(Weather $weather)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Weather  $weather
     * @return \Illuminate\Http\Response
     */
    public function edit(Weather $weather)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Weather  $weather
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Weather $weather)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Weather  $weather
     * @return \Illuminate\Http\Response
     */
    public function destroy(Weather $weather)
    {
        //
    }
}
