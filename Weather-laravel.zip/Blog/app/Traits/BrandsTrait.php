<?php
namespace App\Http\Traits;
use App\Models\Product;
trait BrandsTrait {
    public function brandsAll() {
        // Get all the brands from the Brands Table.
        $brands = Product::all();

        return $brands;
    }
}