<!DOCTYPE html>
<html>
<head>
    <title>Nextolive.com</title>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><?php echo e($body); ?></p>
     
    <p>Thank you</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\Blog\resources\views/email/myTestMail.blade.php ENDPATH**/ ?>